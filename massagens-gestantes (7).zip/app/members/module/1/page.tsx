import { Chapter1 } from "@/components/chapters/chapter-1"

export default function Module1Page() {
  return <Chapter1 />
}
