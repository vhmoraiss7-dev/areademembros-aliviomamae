import { Chapter6 } from "@/components/chapters/chapter-6"

export default function Module5Page() {
  return <Chapter6 />
}
