import { Chapter8 } from "@/components/chapters/chapter-8"

export default function Module8Page() {
  return <Chapter8 />
}
