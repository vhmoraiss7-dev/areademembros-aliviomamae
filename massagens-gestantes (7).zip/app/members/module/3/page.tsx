import { Chapter3 } from "@/components/chapters/chapter-3"

export default function Module3Page() {
  return <Chapter3 />
}
