import { Chapter7 } from "@/components/chapters/chapter-7"

export default function Module7Page() {
  return <Chapter7 />
}
